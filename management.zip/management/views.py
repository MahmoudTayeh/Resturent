from django.shortcuts import render

# Create your views here.

def dashboaard_owner(request):
    return render (request, 'dashboard_owner.html')

def login(request):
    return render(request, 'login.html')

def register(request):
    return render(request,'register.html')


def forgotPassword(request):
    return render(request, 'forgot-password.html')

def page_404(request):
    return render(request,'404.html')

def blank_page(request):
    return render(request,'blank.html')

def charts(request):
    return render(request,'charts.html')

def tables(request):
    return render(request,'tables.html')

